# Acknowledgments
https://www.geeksforgeeks.org/linkedhashmap-class-in-java/
https://www.geeksforgeeks.org/check-if-particular-value-exists-in-java-hashmap/
https://stackoverflow.com/questions/15111420/how-to-check-if-a-string-contains-only-digits-in-java
https://www.geeksforgeeks.org/how-to-convert-a-string-to-arraylist-in-java/
https://www.bing.com/search?q=surcharge&qs=n&form=QBRE&sp=-1&lq=0&pq=surcharge&sc=12-9&sk=&cvid=968F095FF3554985A7D9C6AD7E1EBADD
https://www.geeksforgeeks.org/java-string-join-examples/
Chatgpt: create a new identical array, identifying multiple printings